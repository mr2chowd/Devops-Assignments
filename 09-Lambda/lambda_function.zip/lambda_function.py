def handler(event, context):
    # TODO implement
    return print("Hello AWS!"),print(event)